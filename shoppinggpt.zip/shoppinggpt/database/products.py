"""
ShoppingGPT - Product Database
Central mock database for all products.
In production, replace with a real DB (PostgreSQL, MongoDB, etc.)
"""

PRODUCTS = [
    # ── Mobile Phones ──────────────────────────────────────────────
    {
        "id": "p001",
        "emoji": "📱",
        "name": "Pixel 8 Pro",
        "brand": "Google",
        "category": "Mobile",
        "subcategory": "Android",
        "price": 106999,
        "original": 110000,
        "discount": 3,
        "rating": 4.7,
        "reviews": 2341,
        "stock": 15,
        "desc": "The best AI-powered camera phone with Google's Tensor G3 chip.",
        "specs": {"RAM": "12GB", "Storage": "128GB", "Battery": "5050mAh", "Display": "6.7\" LTPO OLED"},
        "tags": ["5g", "ai-camera", "android", "flagship"],
        "in_stock": True
    },
    {
        "id": "p002",
        "emoji": "📱",
        "name": "Galaxy S24 Ultra",
        "brand": "Samsung",
        "category": "Mobile",
        "subcategory": "Android",
        "price": 129999,
        "original": 139999,
        "discount": 7,
        "rating": 4.9,
        "reviews": 5621,
        "stock": 8,
        "desc": "Titanium build with 200MP camera and built-in S Pen.",
        "specs": {"RAM": "12GB", "Storage": "256GB", "Battery": "5000mAh", "Display": "6.8\" Dynamic AMOLED"},
        "tags": ["5g", "s-pen", "200mp", "flagship", "titanium"],
        "in_stock": True
    },
    {
        "id": "p003",
        "emoji": "📱",
        "name": "iPhone 15 Pro Max",
        "brand": "Apple",
        "category": "Mobile",
        "subcategory": "iOS",
        "price": 159900,
        "original": 174900,
        "discount": 9,
        "rating": 4.8,
        "reviews": 8912,
        "stock": 5,
        "desc": "A17 Pro chip, titanium design with Action button and USB-C.",
        "specs": {"RAM": "8GB", "Storage": "256GB", "Battery": "4422mAh", "Display": "6.7\" Super Retina XDR"},
        "tags": ["ios", "a17-pro", "titanium", "flagship", "5g"],
        "in_stock": True
    },
    {
        "id": "p004",
        "emoji": "📱",
        "name": "OnePlus 12",
        "brand": "OnePlus",
        "category": "Mobile",
        "subcategory": "Android",
        "price": 64999,
        "original": 69999,
        "discount": 7,
        "rating": 4.6,
        "reviews": 3102,
        "stock": 22,
        "desc": "Snapdragon 8 Gen 3 with 100W SuperVOOC charging.",
        "specs": {"RAM": "16GB", "Storage": "256GB", "Battery": "5400mAh", "Display": "6.82\" LTPO AMOLED"},
        "tags": ["fast-charging", "snapdragon", "flagship", "5g"],
        "in_stock": True
    },

    # ── Laptops ────────────────────────────────────────────────────
    {
        "id": "p005",
        "emoji": "💻",
        "name": "MacBook Air M3",
        "brand": "Apple",
        "category": "Laptops",
        "subcategory": "Ultrabook",
        "price": 114900,
        "original": 124900,
        "discount": 8,
        "rating": 4.8,
        "reviews": 4521,
        "stock": 12,
        "desc": "Thin, light, and incredibly fast with 18-hour battery life.",
        "specs": {"Chip": "Apple M3", "RAM": "8GB", "Storage": "256GB SSD", "Display": "13.6\" Liquid Retina"},
        "tags": ["m3", "ultrabook", "macos", "thin-light"],
        "in_stock": True
    },
    {
        "id": "p006",
        "emoji": "💻",
        "name": "Dell XPS 15",
        "brand": "Dell",
        "category": "Laptops",
        "subcategory": "Premium",
        "price": 149999,
        "original": 164999,
        "discount": 9,
        "rating": 4.6,
        "reviews": 1872,
        "stock": 7,
        "desc": "OLED display, Intel Core i7, dedicated GPU for professionals.",
        "specs": {"CPU": "Intel i7-13700H", "RAM": "16GB DDR5", "Storage": "512GB SSD", "Display": "15.6\" OLED 3.5K"},
        "tags": ["oled", "intel", "nvidia", "professional"],
        "in_stock": True
    },
    {
        "id": "p007",
        "emoji": "💻",
        "name": "Lenovo IdeaPad Slim 5",
        "brand": "Lenovo",
        "category": "Laptops",
        "subcategory": "Budget",
        "price": 52999,
        "original": 62999,
        "discount": 16,
        "rating": 4.3,
        "reviews": 3201,
        "stock": 30,
        "desc": "Ryzen 5 7530U, great value everyday laptop for students.",
        "specs": {"CPU": "AMD Ryzen 5 7530U", "RAM": "8GB", "Storage": "512GB SSD", "Display": "15.6\" IPS FHD"},
        "tags": ["budget", "amd", "student", "everyday"],
        "in_stock": True
    },

    # ── Audio ──────────────────────────────────────────────────────
    {
        "id": "p008",
        "emoji": "🎧",
        "name": "Sony WH-XM5",
        "brand": "Sony",
        "category": "Earbuds",
        "subcategory": "Over-ear",
        "price": 24990,
        "original": 34990,
        "discount": 29,
        "rating": 4.8,
        "reviews": 9823,
        "stock": 45,
        "desc": "Industry-leading noise cancellation with 30-hour battery.",
        "specs": {"Type": "Over-ear", "ANC": "Yes", "Battery": "30 hrs", "Connectivity": "Bluetooth 5.2"},
        "tags": ["anc", "over-ear", "premium", "sony"],
        "in_stock": True
    },
    {
        "id": "p009",
        "emoji": "🎧",
        "name": "AirPods Pro 2",
        "brand": "Apple",
        "category": "Earbuds",
        "subcategory": "In-ear",
        "price": 24900,
        "original": 26900,
        "discount": 7,
        "rating": 4.7,
        "reviews": 14200,
        "stock": 60,
        "desc": "Adaptive audio, personalized spatial audio and USB-C charging.",
        "specs": {"Type": "In-ear TWS", "ANC": "Adaptive", "Battery": "6+30 hrs", "Connectivity": "Bluetooth 5.3"},
        "tags": ["anc", "tws", "apple-ecosystem", "spatial-audio"],
        "in_stock": True
    },
    {
        "id": "p010",
        "emoji": "🎧",
        "name": "Boat Airdopes 141",
        "brand": "Boat",
        "category": "Earbuds",
        "subcategory": "Budget TWS",
        "price": 1299,
        "original": 2990,
        "discount": 57,
        "rating": 4.1,
        "reviews": 52000,
        "stock": 200,
        "desc": "Budget TWS with 42-hour playback and ENx tech.",
        "specs": {"Type": "TWS", "ANC": "No", "Battery": "6+36 hrs", "Connectivity": "Bluetooth 5.0"},
        "tags": ["budget", "tws", "india", "value"],
        "in_stock": True
    },

    # ── Shoes ──────────────────────────────────────────────────────
    {
        "id": "p011",
        "emoji": "👟",
        "name": "Air Max 270",
        "brand": "Nike",
        "category": "Shoes",
        "subcategory": "Running",
        "price": 12500,
        "original": 15000,
        "discount": 17,
        "rating": 4.4,
        "reviews": 4321,
        "stock": 50,
        "desc": "Largest Air unit for all-day comfort and style.",
        "specs": {"Type": "Lifestyle/Running", "Upper": "Mesh + Synthetic", "Sole": "Air Max unit", "Sizes": "6-13 UK"},
        "tags": ["running", "air-max", "lifestyle", "cushioned"],
        "in_stock": True
    },
    {
        "id": "p012",
        "emoji": "👟",
        "name": "Ultraboost 23",
        "brand": "Adidas",
        "category": "Shoes",
        "subcategory": "Running",
        "price": 14000,
        "original": 18000,
        "discount": 22,
        "rating": 4.6,
        "reviews": 2891,
        "stock": 35,
        "desc": "Responsive Boost midsole for exceptional energy return.",
        "specs": {"Type": "Running", "Upper": "Primeknit+", "Sole": "Boost + Continental", "Sizes": "6-13 UK"},
        "tags": ["running", "boost", "performance", "marathon"],
        "in_stock": True
    },

    # ── Smartwatches ───────────────────────────────────────────────
    {
        "id": "p013",
        "emoji": "⌚",
        "name": "Apple Watch Ultra 2",
        "brand": "Apple",
        "category": "Smartwatch",
        "subcategory": "Premium",
        "price": 89900,
        "original": 89900,
        "discount": 0,
        "rating": 4.9,
        "reviews": 3210,
        "stock": 10,
        "desc": "Most rugged Apple Watch with 60-hour battery and precision GPS.",
        "specs": {"Display": "49mm LTPO OLED", "Battery": "60 hrs", "Water": "100m", "OS": "watchOS 10"},
        "tags": ["premium", "rugged", "gps", "apple-ecosystem"],
        "in_stock": True
    },
    {
        "id": "p014",
        "emoji": "⌚",
        "name": "Galaxy Watch 6 Classic",
        "brand": "Samsung",
        "category": "Smartwatch",
        "subcategory": "Mid-range",
        "price": 34999,
        "original": 42999,
        "discount": 19,
        "rating": 4.5,
        "reviews": 2100,
        "stock": 18,
        "desc": "Rotating bezel, advanced health tracking with BioActive sensor.",
        "specs": {"Display": "47mm Super AMOLED", "Battery": "40 hrs", "Water": "5ATM", "OS": "Wear OS 4"},
        "tags": ["rotating-bezel", "health", "android", "wear-os"],
        "in_stock": True
    },

    # ── Gaming ─────────────────────────────────────────────────────
    {
        "id": "p015",
        "emoji": "🎮",
        "name": "PlayStation 5",
        "brand": "Sony",
        "category": "Gaming",
        "subcategory": "Console",
        "price": 44990,
        "original": 54990,
        "discount": 18,
        "rating": 4.8,
        "reviews": 12400,
        "stock": 6,
        "desc": "Next-gen gaming with ultra-fast SSD and DualSense haptics.",
        "specs": {"CPU": "AMD Zen 2 8-core", "GPU": "10.3 TFLOPS RDNA 2", "Storage": "825GB SSD", "Resolution": "8K capable"},
        "tags": ["console", "4k", "next-gen", "exclusive-games"],
        "in_stock": True
    },
    {
        "id": "p016",
        "emoji": "🎮",
        "name": "Xbox Series X",
        "brand": "Microsoft",
        "category": "Gaming",
        "subcategory": "Console",
        "price": 44990,
        "original": 52990,
        "discount": 15,
        "rating": 4.7,
        "reviews": 8900,
        "stock": 9,
        "desc": "Most powerful Xbox ever — 4K at 120fps with Game Pass.",
        "specs": {"CPU": "AMD Zen 2 8-core", "GPU": "12 TFLOPS RDNA 2", "Storage": "1TB NVMe SSD", "Resolution": "4K/120fps"},
        "tags": ["console", "4k", "game-pass", "backwards-compatible"],
        "in_stock": True
    },
]

def get_all_products():
    return PRODUCTS

def get_product_by_id(product_id):
    return next((p for p in PRODUCTS if p['id'] == product_id), None)

def get_categories():
    return sorted(list(set(p['category'] for p in PRODUCTS)))

def get_brands():
    return sorted(list(set(p['brand'] for p in PRODUCTS)))

def search_products(query='', category=None, brand=None, max_price=None, min_rating=None, sort_by='rating'):
    results = PRODUCTS[:]

    if category:
        results = [p for p in results if p['category'].lower() == category.lower()]
    if brand:
        results = [p for p in results if p['brand'].lower() == brand.lower()]
    if max_price:
        results = [p for p in results if p['price'] <= max_price]
    if min_rating:
        results = [p for p in results if p['rating'] >= min_rating]
    if query:
        q = query.lower()
        results = [p for p in results if
                   q in p['name'].lower() or
                   q in p['brand'].lower() or
                   q in p['category'].lower() or
                   q in p['desc'].lower() or
                   any(q in t for t in p['tags'])]
    if sort_by == 'price_asc':
        results.sort(key=lambda x: x['price'])
    elif sort_by == 'price_desc':
        results.sort(key=lambda x: x['price'], reverse=True)
    elif sort_by == 'discount':
        results.sort(key=lambda x: x['discount'], reverse=True)
    else:
        results.sort(key=lambda x: x['rating'], reverse=True)

    return results
