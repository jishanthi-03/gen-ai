"""
Configuration Settings for ShoppingGPT
"""
import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'shoppinggpt-dev-secret-2024')
    ANTHROPIC_API_KEY = os.environ.get('ANTHROPIC_API_KEY', '')
    CLAUDE_MODEL = 'claude-sonnet-4-20250514'
    MAX_TOKENS = 1500
    MAX_HISTORY = 10  # Max conversation turns to keep in memory
    DEBUG = os.environ.get('FLASK_DEBUG', 'true').lower() == 'true'
