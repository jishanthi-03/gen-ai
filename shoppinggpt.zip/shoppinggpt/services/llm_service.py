"""
ShoppingGPT - LLM Service
Handles all interactions with the Claude AI model.
"""

import json
import anthropic
from flask import current_app
from database.products import get_all_products

# ── System Prompt ──────────────────────────────────────────────────────────────

def build_system_prompt():
    products = get_all_products()
    catalog_json = json.dumps(products, indent=2)

    return f"""You are ShoppingGPT, a friendly, knowledgeable AI shopping assistant for an Indian e-commerce platform. Your job is to help users find the perfect products, compare options, and make smart purchase decisions.

PRODUCT CATALOG:
{catalog_json}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RESPONSE FORMAT (STRICT JSON ONLY)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Always respond with a single valid JSON object. Never include markdown, backticks, or any text outside the JSON.

Schema:
{{
  "type": "greet" | "results" | "compare" | "detail" | "not_found" | "chat",
  "message": "Your friendly response text here",
  "products": [...],       // Array of matched product objects from catalog
  "tip": "optional deal or advice tip",
  "suggestions": ["quick follow-up suggestion 1", "suggestion 2"]  // 2-3 short suggestions
}}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BEHAVIOR RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. PRODUCT MATCHING:
   - Match by name, brand, category, subcategory, desc, tags keywords
   - "phones" → Mobile category | "headphones" → Earbuds | "watch" → Smartwatch
   - "Apple" → all Apple products | "Sony" → Sony products
   - Budget queries: "under ₹X" or "under X" → filter price <= X
   - "cheap" / "budget" → price < 15000 | "mid-range" → 15000–60000 | "premium" / "flagship" → >60000

2. SORTING:
   - Default: sort by rating desc
   - "best deals" / "highest discount" → sort by discount desc
   - "cheapest" → sort by price asc
   - "most expensive" / "best" / "top" → sort by price desc or rating desc

3. RESPONSE TYPES:
   - Greeting/chitchat → type="greet", products=[]
   - Product search → type="results", include matched products[]
   - Compare two+ products → type="compare", highlight pros/cons in message
   - No match → type="not_found", suggest alternatives
   - General help → type="chat", products=[]

4. QUALITY:
   - message must be warm, concise (2–3 sentences max)
   - Always include 2-3 suggestions for follow-up
   - tip should be genuinely useful (deal alert, comparison insight, use-case advice)
   - ONLY return products that exist in the catalog above — never invent products
   - Prices are in Indian Rupees (₹)

5. CONTEXT AWARENESS:
   - Remember conversation history — if user says "show me cheaper ones", filter based on previous search
   - If user asks "which is better" without specifying, ask for clarification via message
"""

# ── Main LLM Call ──────────────────────────────────────────────────────────────

def get_ai_response(user_message: str, conversation_history: list) -> dict:
    """
    Send a message to Claude and get a structured JSON response.

    Args:
        user_message: The user's latest message
        conversation_history: List of past {"role": ..., "content": ...} dicts

    Returns:
        Parsed dict with type, message, products, tip, suggestions
    """
    api_key = current_app.config.get('ANTHROPIC_API_KEY')
    if not api_key:
        return _error_response("ANTHROPIC_API_KEY is not set in environment.")

    client = anthropic.Anthropic(api_key=api_key)

    # Build messages: past history + new user message
    max_hist = current_app.config.get('MAX_HISTORY', 10)
    messages = conversation_history[-(max_hist * 2):]  # keep last N turns
    messages.append({"role": "user", "content": user_message})

    try:
        response = client.messages.create(
            model=current_app.config.get('CLAUDE_MODEL', 'claude-sonnet-4-20250514'),
            max_tokens=current_app.config.get('MAX_TOKENS', 1500),
            system=build_system_prompt(),
            messages=messages
        )

        raw_text = response.content[0].text.strip()

        # Strip accidental markdown fences
        if raw_text.startswith("```"):
            raw_text = raw_text.split("```")[1]
            if raw_text.startswith("json"):
                raw_text = raw_text[4:]
            raw_text = raw_text.strip()

        parsed = json.loads(raw_text)

        # Ensure required fields exist
        parsed.setdefault('type', 'chat')
        parsed.setdefault('message', '')
        parsed.setdefault('products', [])
        parsed.setdefault('tip', None)
        parsed.setdefault('suggestions', [])

        return parsed

    except json.JSONDecodeError as e:
        return _error_response(f"AI returned invalid JSON: {str(e)}")
    except anthropic.AuthenticationError:
        return _error_response("Invalid Anthropic API key. Please check your ANTHROPIC_API_KEY.")
    except anthropic.RateLimitError:
        return _error_response("Rate limit reached. Please try again in a moment.")
    except Exception as e:
        return _error_response(f"Unexpected error: {str(e)}")


def _error_response(message: str) -> dict:
    return {
        "type": "error",
        "message": message,
        "products": [],
        "tip": None,
        "suggestions": ["Try again", "Search for phones", "Browse laptops"]
    }
