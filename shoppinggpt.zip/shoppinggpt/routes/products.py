"""
ShoppingGPT - Products REST API
Browse/filter products without using the chat interface.
"""

from flask import Blueprint, request, jsonify
from database.products import get_all_products, get_product_by_id, get_categories, get_brands, search_products

products_bp = Blueprint('products', __name__)


@products_bp.route('/products', methods=['GET'])
def list_products():
    """List all products with optional filters."""
    category  = request.args.get('category')
    brand     = request.args.get('brand')
    max_price = request.args.get('max_price', type=int)
    min_rating = request.args.get('min_rating', type=float)
    query     = request.args.get('q', '')
    sort_by   = request.args.get('sort', 'rating')

    results = search_products(
        query=query,
        category=category,
        brand=brand,
        max_price=max_price,
        min_rating=min_rating,
        sort_by=sort_by
    )
    return jsonify({"count": len(results), "products": results})


@products_bp.route('/products/<product_id>', methods=['GET'])
def get_product(product_id):
    """Get a single product by ID."""
    product = get_product_by_id(product_id)
    if not product:
        return jsonify({"error": "Product not found"}), 404
    return jsonify(product)


@products_bp.route('/categories', methods=['GET'])
def list_categories():
    return jsonify({"categories": get_categories()})


@products_bp.route('/brands', methods=['GET'])
def list_brands():
    return jsonify({"brands": get_brands()})
