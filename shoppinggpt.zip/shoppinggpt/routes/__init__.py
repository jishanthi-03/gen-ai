# ShoppingGPT Routes Package
