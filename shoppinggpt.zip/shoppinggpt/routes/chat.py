"""
ShoppingGPT - Chat Route
Handles the /api/chat endpoint for LLM-powered conversations.
"""

from flask import Blueprint, request, jsonify, session
from services.llm_service import get_ai_response

chat_bp = Blueprint('chat', __name__)


@chat_bp.route('/chat', methods=['POST'])
def chat():
    data = request.get_json(silent=True)
    if not data or 'message' not in data:
        return jsonify({"error": "Missing 'message' in request body"}), 400

    user_message = data['message'].strip()
    if not user_message:
        return jsonify({"error": "Message cannot be empty"}), 400

    # Get or init conversation history from session
    if 'history' not in session:
        session['history'] = []

    history = session['history']

    # Call LLM
    response = get_ai_response(user_message, history)

    # Append both turns to history
    history.append({"role": "user", "content": user_message})
    history.append({"role": "assistant", "content": str(response)})

    # Keep history manageable
    if len(history) > 20:
        history = history[-20:]
    session['history'] = history

    return jsonify(response)


@chat_bp.route('/chat/reset', methods=['POST'])
def reset_chat():
    """Clear conversation history to start fresh."""
    session.pop('history', None)
    return jsonify({"status": "ok", "message": "Conversation reset."})
