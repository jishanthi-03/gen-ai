# ShoppingGPT 🛍️

An AI-powered shopping assistant built with **Flask + Claude AI (Anthropic)**.

---

## Project Structure

```
shoppinggpt/
├── app.py                  ← Flask app factory & entry point
├── config.py               ← Configuration (API keys, model settings)
├── requirements.txt        ← Python dependencies
├── .env.example            ← Environment variable template
│
├── database/
│   ├── __init__.py
│   └── products.py         ← Product catalog + search/filter functions
│
├── services/
│   ├── __init__.py
│   └── llm_service.py      ← Claude AI integration (system prompt + API call)
│
├── routes/
│   ├── __init__.py
│   ├── pages.py            ← Serves index.html
│   ├── chat.py             ← POST /api/chat  |  POST /api/chat/reset
│   └── products.py         ← REST API: GET /api/products, /api/categories, etc.
│
└── templates/
    └── index.html          ← Full frontend UI (dark theme, sidebar, chat)
```

---

## Setup & Run

### 1. Clone / place the project folder

```bash
cd shoppinggpt
```

### 2. Create a virtual environment

```bash
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Set your API key

```bash
cp .env.example .env
# Edit .env and paste your Anthropic API key
```

Or export directly:
```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

### 5. Run the server

```bash
python app.py
```

Open **http://localhost:5000** in your browser.

---

## API Reference

| Method | Endpoint                   | Description                          |
|--------|----------------------------|--------------------------------------|
| POST   | `/api/chat`                | Send a message, get AI response      |
| POST   | `/api/chat/reset`          | Clear conversation history           |
| GET    | `/api/products`            | List all products (supports filters) |
| GET    | `/api/products/<id>`       | Get single product by ID             |
| GET    | `/api/categories`          | List all categories                  |
| GET    | `/api/brands`              | List all brands                      |

### POST `/api/chat`

**Request:**
```json
{ "message": "Show me Sony earbuds under 30000" }
```

**Response:**
```json
{
  "type": "results",
  "message": "Here are the Sony earbuds in your budget!",
  "products": [ { ... }, { ... } ],
  "tip": "The WH-XM5 is currently 29% off — best deal in this category.",
  "suggestions": ["Compare with AirPods Pro", "Show cheaper options", "Best rated earbuds"]
}
```

### GET `/api/products` — Query Parameters

| Param       | Type   | Example              |
|-------------|--------|----------------------|
| `q`         | string | `?q=samsung`         |
| `category`  | string | `?category=Mobile`   |
| `brand`     | string | `?brand=Sony`        |
| `max_price` | int    | `?max_price=30000`   |
| `min_rating`| float  | `?min_rating=4.5`    |
| `sort`      | string | `?sort=discount`     |

Sort options: `rating` (default), `price_asc`, `price_desc`, `discount`

---

## How It Works

1. **User** types a query in the chat input.
2. **Frontend** sends `POST /api/chat` with the message.
3. **Flask** retrieves the session conversation history.
4. **`llm_service.py`** builds a system prompt that includes the **full product catalog as JSON** and sends it + conversation history to **Claude AI**.
5. **Claude** returns a structured JSON response with `type`, `message`, `products[]`, `tip`, and `suggestions`.
6. **Frontend** renders the response — product cards, suggestions, tips.

---

## Extending the Project

- **Real database**: Replace `database/products.py` with SQLAlchemy models + PostgreSQL
- **User auth**: Add Flask-Login for user accounts and wishlists
- **Cart**: Add session-based or DB-backed cart endpoints
- **More LLM features**: Add tool use / function calling for real-time price checks
- **Image search**: Add product images and image-based search
