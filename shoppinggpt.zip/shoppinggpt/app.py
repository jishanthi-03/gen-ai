"""
ShoppingGPT - AI-Powered Shopping Assistant
Main Flask Application Entry Point
"""

from flask import Flask
from config import Config
from routes.chat import chat_bp
from routes.products import products_bp
from routes.pages import pages_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Register Blueprints
    app.register_blueprint(pages_bp)
    app.register_blueprint(chat_bp, url_prefix='/api')
    app.register_blueprint(products_bp, url_prefix='/api')

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, port=5000)
